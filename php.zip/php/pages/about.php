<?php if ( function_exists('wp_is_mobile') && wp_is_mobile() ): ?>
	<h2>About us</h2>
	<div class="aboutus">
		<p>
			眼帯の下はどんな目をしているんだろう<br>
			なぜ眼帯をしているんだろう<br>
			過去に何があったんだろう<br>
			気がつくと隠されている片目の魅力に引き込まれてしまう<br>
			それが片目惚れ~hitomebore~<br>
			私達はそんな片目惚れを紹介致します<br>
		</p>
		<a href="https://www.facebook.com/KAPAPIBARAsan" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/shared/img/sakaki.png" alt="sakakibara"></a>
		<h4>片目惚れ~hitomebore~ 代表兼カメラマン</h4>
		<h3>榊原清一</h3>
	</div>
<?php else: ?><!-- /sp -->

<img src="http://hitome-bore.com/wp-content/uploads/2012/12/aboutUs-670x445.jpg" alt="aboutUs" width="670" height="445" class="alignnone size-medium wp-image-642" />
<a title="運営情報" target=”_blank” href="http://www.facebook.com/KAPAPIBARAsan">代表facebookページ</a>
<?php endif; ?><!-- /PC -->
